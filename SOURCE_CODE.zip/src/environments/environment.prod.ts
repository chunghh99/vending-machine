export const environment = {
  apiUrl: 'https://vending.koyeb.app',
};
